import logging
from logging.config import dictConfig
import os
from os import path
from logging_conf import LOGGING_CONFIG

dictConfig(LOGGING_CONFIG)

# config_path = path.join(path.dirname(path.abspath(__file__)), 'logging.conf')

# Get the logger specified in the file
logger = logging.getLogger('')
logger1 = logging.getLogger('log1')
logger_new = logging.getLogger('logger1')
logger_new2 = logging.getLogger('logger2')


logger.debug('write in logger')
logger_new.info("Write in logger1")
logger_new.error("Write in logger error")
logger_new2.error("This is a new error log")
logger1.info('This is the info log')
