import logging
import logging.config
import os
from os import path

config_path = path.join(path.dirname(path.abspath(__file__)), 'logging.conf')

logging.config.fileConfig(fname=config_path, disable_existing_loggers=False)

# Get the logger specified in the file
logger = logging.getLogger('simpleExample')
logger1 = logging.getLogger('new')
logger2 = logging.getLogger('old')
logger3 = logging.getLogger('me')

logger.debug('write in logger')
logger1.debug("Write in logger1")
logger2.debug("Write in logger2")
logger3.debug("Write in logger root")
