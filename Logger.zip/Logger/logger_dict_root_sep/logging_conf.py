

LOGGING_CONFIG = {
    'version': 1,
    'root':  {  # root logger
        'level': 'NOTSET',
        'handlers': ['debug_console_handler', 'file_handler'],
    },
    'loggers': {
        'logger1': {
            'level': 'DEBUG',
            'propagate': False,
            'handlers': ['info_file_handler', 'error_file_handler'],
        },
        'logger2': {
            'level': 'INFO',
            'propagate': False,
            'handlers': ['debug_console_handler', 'error_file_handler'],
        },
    },
    'handlers': {
        'debug_console_handler': {
            'level': 'DEBUG',
            'formatter': 'info',
            'class': 'logging.StreamHandler',
            'stream': 'ext://sys.stdout',
        },
        'info_file_handler': {
            'level': 'INFO',
            'formatter': 'info',
            'class': 'logging.FileHandler',
            'filename': '/root/swagat/logger_dict_root_sep/log.txt',
            'mode': 'a',
        },
        'error_file_handler': {
            'level': 'WARNING',
            'formatter': 'error',
            'class': 'logging.FileHandler',
            'filename': '/root/swagat/logger_dict_root_sep/error.log',
            'mode': 'a',
        },
        'file_handler': {
            'level': 'DEBUG',
            'formatter': 'info',
            'class': 'logging.FileHandler',
            'filename': '/root/swagat/logger_dict_root_sep/default_log.txt',
            'mode': 'a',
        },
    },
    'formatters': {
        'info': {
            'format': '%(asctime)s-%(levelname)s-%(name)s::%(module)s|%(lineno)s:: %(message)s'
        },
        'error': {
            'format': '%(asctime)s-%(levelname)s-%(name)s-%(process)d::%(module)s|%(lineno)s:: %(message)s'
        },
    },

}
